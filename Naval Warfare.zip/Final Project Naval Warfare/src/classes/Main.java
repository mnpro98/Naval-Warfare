package classes;

//the imports
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author Mauricio Na�ez and Enrique Pe�a
 * @version 1.00
 * @since 2016/05/03
 */
public class Main {
	/**
	 * Initializing class variables.
	 */
	static Scanner sc = new Scanner(System.in);
	private static int position = 0;
	private static int wSpeed = 0;
	private static int[][] map = new int[34][34];
	private static String name = null;
	private static int score = 10000;
	private static List<String[]> scores = new ArrayList<String[]>();
	private static String mode = "";

	/**
	 * This is the main method. It's where the main menu is.
	 *
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws EOFException
	 * @throws ClassNotFoundException
	 */
	public static void main(String[] args) // protection against errors
			throws IOException, FileNotFoundException, EOFException, ClassNotFoundException {
		InputStreamReader inStream = new InputStreamReader(System.in);
		BufferedReader stdIn = new BufferedReader(inStream); // creates a new
																// BufferedReader
		// initializing variables
		String csvFile = "test.csv";
		String line = "";
		String cvsSplitBy = ",";
		BufferedReader br = null;
		FileWriter writer;
		String[] aScore = new String[3];
		try {// try and catch if the program cannot find the csv file.
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) { // Checks for lines
				aScore = line.split(cvsSplitBy);
				scores.add(aScore);
			}
		} catch (FileNotFoundException e) {
			try {
				aScore[0] = "Player";
				aScore[1] = "Score";
				aScore[2] = "Difficulty";
				scores.add(aScore);
			} catch (Exception e2) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		boolean run = true; // this loop keeps the program running until the
							// user selects exit
		while (run) {
			System.out.println("Welcome to Naval Warfare: Battleship Edition");
			System.out.println("Please enter your name:");
			name = sc.nextLine();
			System.out.println("-------------------------------------------------------");
			boolean onMenu = true;
			while (onMenu) { // keeps the user from exiting the menu until they
								// exit the program
				System.out.println("Main Menu");
				System.out.println("1)\tPlay!");
				System.out.println("2)\tLeaderboards");
				System.out.println("3)\tEdit Name");
				System.out.println("9)\tExit");
				try {
					int menuOption = sc.nextInt();
					switch (menuOption) { // switch case for the menu selection.
					case 1: // will access the game method
						game();
						break;
					case 2: // will access the leaderboards
						System.out.println("Leaderboards:");
						for (int i = 0; i < scores.size(); i++) { // a for loop
																	// to
																	// display
																	// the
																	// scores
																	// from the
																	// list
							System.out.println(scores.get(i)[0] + "\t" + scores.get(i)[1] + "\t" + scores.get(i)[2]);
						}
						System.out.println("Press enter to continue \n");
						stdIn.readLine();
						break;
					case 3: // if the user wants to change its name
						name = null;
						System.out.println("Please enter your name:");
						name = sc.next();
						break;
					case 9: // saves the scores and exits the program
						System.out.println("Saving...");
						writer = new FileWriter(csvFile);
						for (int i = 0; i < scores.size(); i++) {
							writer.append(scores.get(i)[0]);
							writer.append(',');
							writer.append(scores.get(i)[1]);
							writer.append(',');
							writer.append(scores.get(i)[2]);
							writer.append('\n');
						}
						//closes the writer
						writer.flush();
						writer.close();
						System.out.println("Good Bye!");
						onMenu = false;
						System.exit(0);
					default:
						System.out.println("Please enter a valid number...");
					}
				} catch (Exception e) {
					System.out.println("Please enter a valid number...");
					break;
				}
			}
		}
	}

	/**
	 * This method generates the CSV file.
	 *
	 * @param sFileName
	 */
	private static void generateCsvFile(String sFileName) {
		try {
			FileWriter writer = new FileWriter(sFileName);
			writer.append('\n'); // New Line sequence
			writer.append(name); // Writes the user's name
			writer.append(','); // Comma Separator
			writer.append("" + score); // Writes the score
			writer.append(',');// Comma Separator
			writer.append(mode);// Writes the difficulty mode.
			writer.append('\n'); // New Line sequence
			writer.flush(); // Flushes the Filewriter
			writer.close(); // Closes the Filewriter
		} catch (IOException e) {
			e.printStackTrace(); // returns if something's wrong
		}
	}
		/**
		 * The method game is the one in which the code of the parabolic shooting is written, its functions include:
		 * -letting the user choose his battleship and the enemy's ship
		 * -giving information about the ships
		 * -making the calculation for the shoot
		 * -displaying a matrix based on the position of the ships
		 * -asks the user for the direction and elevation angles
		 * -and saves the score
		 */
		public static void game() throws IOException {
			InputStreamReader inStream = new InputStreamReader(System.in);
			BufferedReader stdIn = new BufferedReader(inStream);
			boolean menu1 = true;
			Battleship ally = new Battleship(1);
			String enemyBattleShip = "";
			//menu that lets you choose your country//
			while (menu1) {
				System.out.println("Choose your country:");
				System.out.println("1)\tBritish Empire");
				System.out.println("2)\tNazi Germany");
				System.out.println("3)\tFrench Third Republic");
				System.out.println("4)\tUnion of Soviet Socialists States");
				System.out.println("5)\tUnited States of America");
				System.out.println("6)\tEmpire of Japan");
				System.out.println("7)\tKingdom of Italy");
				try {
					int gameMenuOption1 = sc.nextInt();
					switch (gameMenuOption1) {
					case 1:
						// yourBattleShip = "HMS Prince of Wales";
					case 2:
						// yourBattleShip = "Bismarck";
					case 3:
						// yourBattleShip = "The Dunkerque";
					case 4:
						// yourBattleShip = "Sovetsky Soyuz";
					case 5:
						// yourBattleShip = "USS Missouri";
					case 6:
						// yourBattleShip = "The Yamato";
					case 7:
						// yourBattleShip = "Littorio";
						ally = new Battleship(gameMenuOption1);
						break;
					default:
						System.out.println("Invalid Input");
						System.out.println("The program will decide your ship");
						break;
					}
					System.out.println("Your battleship is " + ally.name);
					boolean menu2 = true;
					//menu for enemy's battleship//
					while (menu2) {
						System.out.println("Choose your enemy:");
						System.out.println("1)\tBritish Empire");
						System.out.println("2)\tNazi Germany");
						System.out.println("3)\tFrench Third Republic");
						System.out.println("4)\tUnion of Soviet Socialists States");
						System.out.println("5)\tUnited States of America");
						System.out.println("6)\tEmpire of Japan");
						System.out.println("7)\tKingdom of Italy");
						try {
							int gameMenuOption2 = sc.nextInt();
							switch (gameMenuOption2) {
							case 1:
								enemyBattleShip = "HMS Prince of Wales";
								break;
							case 2:
								enemyBattleShip = "Bismarck";
								break;
							case 3:
								enemyBattleShip = "The Dunkerque";
								break;
							case 4:
								enemyBattleShip = "Sovetsky Soyuz";
								break;
							case 5:
								enemyBattleShip = "USS Missouri";
								break;
							case 6:
								enemyBattleShip = "The Yamato";
							case 7:
								enemyBattleShip = "Littorio";
								break;
							default:
								System.out.println("Invalid Input");
								System.out.println("The program will decide your enemy");
								enemyBattleShip = "Bismarck";
							}
							//Sets the basic information about your ship and displays it to the user//
							menu2 = false;
							System.out.println("Your enemy is " + enemyBattleShip);
							System.out.println("-------------------------------------------------------");
							System.out.println(ally.name + " " + "Statstics: ");
							System.out.println(ally.year);
							System.out.println("Main Artillery: " + ally.artillery);
							System.out.println("Rate of Fire: " + ally.fireRate + " shots per minute");
							System.out.println("Speed: " + ally.speed + " knots");
							System.out.println("Length: " + ally.length + "m");
							System.out.println("Maximum Armor: " + ally.armor + "mm");
							System.out.println("Muzzle Velocity: " + ally.muzzleVelocity + " m/s");
							System.out.println("-------------------------------------------------------");
							System.out.println("Ready, press enter to begin...");
							stdIn.readLine();
							System.out.println("-------------------------------------------------------");

							//this part receives a random values that determines the position of the ships in a Cartesian plane,
							//it also secures that the ships may not be in the same position by ensuring that your battleship belongs
							//to the second and third quadrant, while your enemy is in the first and fourth (which also simplifies
							//the equations since the vectors are in the same position)

							int youX = randomPosition(position);
							if (youX > 0) {
								youX = youX * -1;
							}
							int youY = randomPosition(position);
							int eneX = randomPosition(position);
							if (eneX < 0) {
								eneX = eneX * -1;
							}
							int eneY = randomPosition(position);

							//Calculates the distance between the two ships (using the Phytagoras theorem)
							double distanceNoWind = Math
									.sqrt((eneX - youX) * (eneX - youX) + (eneY - youY) * (eneY - youY));
							//This part of the codes sets how hard the game will be, the user chooses, it will either:
							//-be easy with no wind movement
							//-be hard and contain wind speed and direction
							int windSpeed = randomWindSpeed(wSpeed);
							System.out.println("Choose Difficulty: (1 or 2)");
							System.out.println("1. Easy");
							System.out.println("2. Hard");
							int gameMode = sc.nextInt();
							if (gameMode == 1) {
								windSpeed = 0;
								System.out.print("No Wind");
								mode = "Easy";
							} else if (gameMode == 2) {
								System.out.println("Wind speed: " + windSpeed + "ms^-1");
								System.out.println("Wind direction: From West to East");
								mode = "Hard";
							} else {
								System.out.println("Invalid Input, the game has automatically chosen hard");
								System.out.println("Wind speed: " + windSpeed + "ms^-1");
								System.out.println("Wind direction: From West to East");
							}
							System.out.println("\nYour position: (" + youX + "m" + youY + "m");
							System.out.println("Enemy position: (" + eneX + "m" + eneY + "m");
							//This section of the code calculates the direction angle assuming there is no wind
							double angleNoWindRadians = (Math.asin((eneY - youY) / distanceNoWind));
							double angleNoWind = ((angleNoWindRadians) * (180 / Math.PI));
							//System.out.println("Direction Angle (No Wind)" + " " + angleNoWind + "�");
							//This section of the code calculates the elevation angle assuming there is no wind
							double elevationAngleInRadians = (Math
									.asin((distanceNoWind * 9.81) / (ally.muzzleVelocity * ally.muzzleVelocity))) / 2;
							double elevationAngle = elevationAngleInRadians * 180 / Math.PI;
							//System.out.println("Elevation Angle (No Wind)" + " " + elevationAngle + "�");
							//This section of the code calculates the values of vectors involving the wind speed
							//b is the x component of the velocity shoot from ship to ship
							//c is the wind speed
							//a is a vector of velocity of the direction angle of the shoot
							//aDistance is a vector of distance of the direction angle of the shoot
							double b = ally.muzzleVelocity * Math.cos(elevationAngleInRadians);
							double c = windSpeed;
							double a = Math.sqrt(b * b + c * c - 2 * b * c * Math.cos(angleNoWindRadians));
							double aDistance = Math.sqrt(
									distanceNoWind * distanceNoWind + c * c - 2 * b * c * Math.cos(angleNoWindRadians));
							//This section calculates the total angle (adding the direction angle with no wind, and the angle
							//formed between vectors a and b
							double totalAngleInRadians = angleNoWindRadians + Math.asin(c * Math.sin(angleNoWind) / a);
							double totalAngle = totalAngleInRadians * 180 / Math.PI;
							//System.out.println("Total Direction Angle = " + totalAngle);
							//This section calculates the elevation angle with wind
							double totalElevationAngleRadians = (Math
									.asin((aDistance * 9.81) / (ally.muzzleVelocity * ally.muzzleVelocity))) / 2;
							double totalElevationAngle = totalElevationAngleRadians * 180 / Math.PI;
							//System.out.println("Total Elevation Angle = " + totalElevationAngle);
							//This section prints a matrix with the position of the ships
							int youMapX = (youX / 1000) + 17;
							int youMapY = (-youY / 1000) + 17;
							int eneMapX = (eneX / 1000) + 17;
							int eneMapY = (-eneY / 1000) + 17;
							System.out.println("Map:");
							for (int i = 0; i < map.length; i++) {
								for (int j = 0; j < map.length; j++) {
									if ((j == (youMapX) && (i == youMapY))) {
										System.out.print("(you)\t");
									} else if ((j == (eneMapX) && (i == eneMapY))) {
										System.out.print("(enemy)\t");
									} else {
										System.out.print("-\t");
									}
								}
								System.out.println("\n");
							}
//							System.out.println(totalElevationAngle);
//							System.out.println(totalAngle);
							//This section asks the user for the values of the elevation and direction angles,
							//(if correct you win, and if you miss the computer shoots you with a 40% chances of destroying you, and the game continues until one battleship wins,
							//sets the score,
							//and gives the user the option to play again or end
							boolean game = true;
							while (game) {
								try {
									System.out.println("Calculate direction angle(from -90� to 90�):");
									double directionInput = sc.nextDouble();
									System.out.println("Calculate the elevation angle(from 0� to 45�):");
									double elevationInput = sc.nextDouble();
									if (elevationInput < (totalElevationAngle + 0.25) && elevationInput > (totalElevationAngle - 0.25)
											&& directionInput < (totalAngle + 0.25)
											&& directionInput > (totalAngle - 0.25)) {
										System.out.println(ally.name + " Wins!");
										System.out.println("Your score: " + score);

										String[] bScore = new String[3];
										bScore[0] = name;
										bScore[1] = "" + score;
										bScore[2] = mode;
										scores.add(bScore);
										generateCsvFile("test.csv");
										game = false;

										System.out.println("Would you like to play again? (y/n)");
										String choice = sc.next();
										if (choice.equals("n")) {
											menu1 = false;
											System.out.println("Choose 9 to exit");
										} else if (choice.equals("y")) {
										} else {
											System.out.println(
													"Since you didn't type n nor y, the program will asume you want to play again");
										}
									} else {
										if (randomWindSpeed(wSpeed) > 5) {
											System.out.println(ally.name + " has missed the target and it has been hit by "
													+ enemyBattleShip + ", \nYou're DEAD...\nGAME OVER!");
											game = false;
											System.out.println("Would you like to play again? (y/n)");
											String choice = sc.next();
											if (choice.equals("n")) {
												menu1 = false;
												System.out.println("Choose 9 to exit");
											} else if (choice.equals("y")) {
											} else {
												System.out.println(
														"Since you didn't type n nor y, the program will asume you want to play again");
											}
										} else {
											System.out.println(ally.name + " has missed the target, but " + enemyBattleShip
													+ " has missed too.");
											score -= 100;
										}
									}
								} catch (Exception e) {
									sc.next();
								}
							}
						} catch (Exception d) {
							System.out.println("Please enter a valid number...");
							sc.next();
						}
					}
				} catch (Exception a) {
					System.out.println("Please enter a valid number...");
					sc.next();
				}
			}
		}
		/**
		 * This method creates a random number between -16935 to 16935
		 * (based on the maximum possible distance shoot with the lowest muzzle velocity)
		 */
		public static int randomPosition(int position) {
			Random rnd = new Random();
			position = rnd.nextInt(33871) - 16935;
			return position;
		}
		/**
		 * This method creates a random number between 1 and 10,
		 * it determines the wind speed in hard mode,
		 * and is used for the possibility in the enemy's shoot
		 */
		public static int randomWindSpeed(int wSpeed) {
			Random rnd = new Random();
			wSpeed = rnd.nextInt(11);
			return wSpeed;
		}
	}