package classes;

/**
 * The Battleship class is an object that extends the Main class.
 * @author Mauricio Na�ez and Enrique Pe�a
 * @version 1.00
 * @since 2016/05/03
 */
public class Battleship extends Main {
	/**
	 * Initializes the object's attributes.
	 */
	String name;
	int year;
	String artillery;
	double fireRate;
	double speed;
	double length;
	int armor;
	int muzzleVelocity;

	/**
	 * This method is accessed by default.
	 */
	public Battleship() {
	}

	/**
	 * This method is accessed if the user inputs a number. Contains all ships' information.
	 * @param type
	 */
	public Battleship(int type) {
		switch (type) { //switch case used to assign the attributes depending on the country chosen.
		case 1: //for British Empire
			this.name = "HMS Prince of Wales";
			this.year = 1936;
			this.artillery = "BL 14 inch Mk VII naval gun";
			this.fireRate = 2;
			this.speed = 28.3;
			this.length = 227.1;
			this.armor = 370;
			this.muzzleVelocity = 730;
			break;
		case 2: //for Nazi Germany
			this.name = "Bismarck";
			this.year = 1939;
			this.artillery = "SK C/34";
			this.fireRate = 2.5;
			this.speed = 30.01;
			this.length = 251;
			this.armor = 360;
			this.muzzleVelocity = 820;
			break;
		case 3: //for France
			this.name = "Dunkerque";
			this.year = 1937;
			this.artillery = "330mm/50 Mod�le 1931";
			this.fireRate = 2;
			this.speed = 31.06;
			this.length = 214.5;
			this.armor = 330;
			this.muzzleVelocity = 830;
			break;
		case 4: //for Soviet Union
			this.name = "Sovetsky Soyuz";
			this.year = 1941;
			this.artillery = "B-37 406mm";
			this.fireRate = 2.2;
			this.speed = 28;
			this.length = 269.4;
			this.armor = 425;
			this.muzzleVelocity = 830;
			break;
		case 5: //For US
			this.name = "USS Missouri";
			this.year = 1940;
			this.artillery = "16''/50 caliber Mark 7 - United States Naval Gun";
			this.fireRate = 2;
			this.speed = 32.7;
			this.length = 270.4;
			this.armor = 310;
			this.muzzleVelocity = 762;
			break;
		case 6: //for Japan
			this.name = "Yamato";
			this.year = 1937;
			this.artillery = "12.7 cm/40 Type 89 naval gun";
			this.fireRate = 2.5;
			this.speed = 27;
			this.length = 263;
			this.armor = 650;
			this.muzzleVelocity = 725;
			break;
		case 7: //for Italy
			this.name = "Littorio";
			this.year = 1937;
			this.artillery = "Cannone da 381/50 Ansaldo M1934";
			this.fireRate = 2;
			this.speed = 30;
			this.length = 237.76;
			this.armor = 350;
			this.muzzleVelocity = 850;
			break;

		}
	}
}